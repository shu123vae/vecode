#include <stdio.h>

int main()
{
    printf("hello world!\n");
    printf("vscode code!\n");
    return 0;
}